import React from 'react';
import { Globe, Info, Store, LogOut, Shield } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';

export const Settings: React.FC = () => {
  const { language, setLanguage, t } = useLanguage();
  const { user, signOut } = useAuth();

  const handleSignOut = async () => {
    if (window.confirm('Are you sure you want to sign out?')) {
      await signOut();
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-6">{t('appSettings')}</h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center mb-4">
            <Globe className="h-6 w-6 text-blue-600 mr-3" />
            <h3 className="text-lg font-semibold text-gray-900">{t('language')}</h3>
          </div>
          
          <div className="space-y-3">
            <label className="flex items-center">
              <input
                type="radio"
                name="language"
                value="en"
                checked={language === 'en'}
                onChange={(e) => setLanguage(e.target.value as 'en')}
                className="mr-3 text-green-600 focus:ring-green-500"
              />
              <span className="text-gray-700">{t('english')}</span>
            </label>
            
            <label className="flex items-center">
              <input
                type="radio"
                name="language"
                value="mr"
                checked={language === 'mr'}
                onChange={(e) => setLanguage(e.target.value as 'mr')}
                className="mr-3 text-green-600 focus:ring-green-500"
              />
              <span className="text-gray-700">{t('marathi')}</span>
            </label>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center mb-4">
            <Shield className="h-6 w-6 text-green-600 mr-3" />
            <h3 className="text-lg font-semibold text-gray-900">Account</h3>
          </div>
          
          <div className="space-y-4">
            <div>
              <span className="text-sm text-gray-500">Signed in as:</span>
              <p className="font-medium text-gray-900">{user?.email}</p>
            </div>
            
            <div>
              <span className="text-sm text-gray-500">Account created:</span>
              <p className="font-medium text-gray-900">
                {user?.created_at ? new Date(user.created_at).toLocaleDateString() : 'N/A'}
              </p>
            </div>
            
            <button
              onClick={handleSignOut}
              className="flex items-center space-x-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
            >
              <LogOut className="h-4 w-4" />
              <span>Sign Out</span>
            </button>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center mb-4">
            <Store className="h-6 w-6 text-green-600 mr-3" />
            <h3 className="text-lg font-semibold text-gray-900">Store Information</h3>
          </div>
          
          <div className="space-y-2">
            <div>
              <span className="text-sm text-gray-500">Store Name:</span>
              <p className="font-medium text-gray-900">Shri Swami Samarth Traders</p>
            </div>
            <div>
              <span className="text-sm text-gray-500">Business Type:</span>
              <p className="font-medium text-gray-900">Grocery Store</p>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
        <div className="flex items-center mb-4">
          <Info className="h-6 w-6 text-purple-600 mr-3" />
          <h3 className="text-lg font-semibold text-gray-900">{t('aboutApp')}</h3>
        </div>
        
        <div className="space-y-4">
          <div>
            <span className="text-sm text-gray-500">{t('version')}:</span>
            <p className="font-medium text-gray-900">1.0.0</p>
          </div>
          
          <div>
            <span className="text-sm text-gray-500">Features:</span>
            <ul className="mt-2 space-y-1 text-sm text-gray-700">
              <li>• Customer credit management</li>
              <li>• WhatsApp reminder integration</li>
              <li>• Multi-language support (English/Marathi)</li>
              <li>• Secure authentication with email and Google login</li>
              <li>• User registration and account management</li>
              <li>• Cloud data synchronization</li>
              <li>• Responsive design for mobile and desktop</li>
            </ul>
          </div>
          
          <div>
            <span className="text-sm text-gray-500">Developer:</span>
            <p className="font-medium text-gray-900">SSS Credit Reminder Team</p>
          </div>
        </div>
      </div>
    </div>
  );
};