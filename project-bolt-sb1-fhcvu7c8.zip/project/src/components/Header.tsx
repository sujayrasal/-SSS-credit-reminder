import React from 'react';
import { Store, TrendingUp, Users } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface HeaderProps {
  totalCustomers: number;
  totalPending: number;
  totalPaid: number;
}

export const Header: React.FC<HeaderProps> = ({ totalCustomers, totalPending, totalPaid }) => {
  const { t } = useLanguage();

  return (
    <header className="bg-white shadow-sm border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center py-6">
          <div className="flex items-center space-x-3 mb-4 sm:mb-0">
            <div className="bg-green-100 p-2 rounded-lg">
              <Store className="h-8 w-8 text-green-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">{t('appTitle')}</h1>
              <p className="text-gray-600">{t('appSubtitle')}</p>
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-6">
            <div className="flex items-center space-x-2 bg-blue-50 px-4 py-2 rounded-lg">
              <Users className="h-5 w-5 text-blue-600" />
              <span className="text-sm font-medium text-blue-900">{totalCustomers} {t('totalCustomers')}</span>
            </div>
            <div className="flex items-center space-x-2 bg-orange-50 px-4 py-2 rounded-lg">
              <TrendingUp className="h-5 w-5 text-orange-600" />
              <span className="text-sm font-medium text-orange-900">₹{totalPending.toFixed(2)} {t('totalPending')}</span>
            </div>
            <div className="flex items-center space-x-2 bg-green-50 px-4 py-2 rounded-lg">
              <TrendingUp className="h-5 w-5 text-green-600" />
              <span className="text-sm font-medium text-green-900">₹{totalPaid.toFixed(2)} {t('totalCollected')}</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};