import React, { useState } from 'react';
import { Edit2, Trash2, MessageCircle, Phone } from 'lucide-react';
import { CustomerRecord } from '../types';
import { formatCurrency } from '../utils/currency';
import { formatDate } from '../utils/date';
import { EditRecordModal } from './EditRecordModal';
import { useLanguage } from '../contexts/LanguageContext';

interface RecordTableProps {
  records: CustomerRecord[];
  onUpdate: (id: string, updates: Partial<CustomerRecord>) => Promise<any>;
  onDelete: (id: string) => Promise<any>;
}

export const RecordTable: React.FC<RecordTableProps> = ({ records, onUpdate, onDelete }) => {
  const { t, language } = useLanguage();
  const [editingRecord, setEditingRecord] = useState<CustomerRecord | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const getStatusBadge = (status: CustomerRecord['payment_status']) => {
    const styles = {
      Pending: 'bg-red-100 text-red-800',
      Partial: 'bg-yellow-100 text-yellow-800',
      Paid: 'bg-green-100 text-green-800',
    };

    const labels = {
      Pending: t('pending'),
      Partial: t('partial'),
      Paid: t('paid'),
    };

    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${styles[status]}`}>
        {labels[status]}
      </span>
    );
  };

  const handleDelete = async (id: string) => {
    if (window.confirm(t('deleteConfirm'))) {
      setDeletingId(id);
      try {
        await onDelete(id);
      } finally {
        setDeletingId(null);
      }
    }
  };

  const handleWhatsAppReminder = (record: CustomerRecord) => {
    const message = t('reminderMessage')
      .replace('{customerName}', record.customer_name)
      .replace('{amount}', record.amount_pending.toFixed(2))
      .replace('{date}', formatDate(record.purchase_date));
    
    const encodedMessage = encodeURIComponent(message);
    
    // If contact number is available, use it; otherwise, open WhatsApp without number
    if (record.customer_contact) {
      const cleanNumber = record.customer_contact.replace(/\D/g, '');
      window.open(`https://wa.me/${cleanNumber}?text=${encodedMessage}`, '_blank');
    } else {
      window.open(`https://wa.me/?text=${encodedMessage}`, '_blank');
    }
  };

  if (records.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8 text-center">
        <p className="text-gray-500">{t('noRecords')}</p>
      </div>
    );
  }

  return (
    <>
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  {t('customerName')}
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  {t('customerContact')}
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  {t('itemsPurchased')}
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  {t('paymentStatus')}
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Amount Details
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {records.map((record) => (
                <tr key={record.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm font-medium text-gray-900">{record.customer_name}</div>
                      <div className="text-sm text-gray-500">{record.store_name}</div>
                      <div className="text-xs text-gray-400">{formatDate(record.purchase_date)}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">
                      {record.customer_contact || '-'}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-gray-900 max-w-xs truncate" title={record.items_purchased}>
                      {record.items_purchased}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {getStatusBadge(record.payment_status)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm text-gray-900">
                        {t('pending')}: <span className="font-medium text-red-600">{formatCurrency(record.amount_pending)}</span>
                      </div>
                      <div className="text-sm text-gray-500">
                        {t('paid')}: <span className="text-green-600">{formatCurrency(record.amount_paid)}</span>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex items-center space-x-2 justify-end">
                      {record.amount_pending > 0 && (
                        <button
                          onClick={() => handleWhatsAppReminder(record)}
                          className="p-2 text-green-600 hover:bg-green-50 rounded-lg transition-colors"
                          title={t('sendReminder')}
                        >
                          <MessageCircle className="h-4 w-4" />
                        </button>
                      )}
                      <button
                        onClick={() => setEditingRecord(record)}
                        className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        title={t('edit')}
                      >
                        <Edit2 className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(record.id!)}
                        disabled={deletingId === record.id}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors disabled:opacity-50"
                        title={t('delete')}
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {editingRecord && (
        <EditRecordModal
          record={editingRecord}
          onUpdate={onUpdate}
          onClose={() => setEditingRecord(null)}
        />
      )}
    </>
  );
};