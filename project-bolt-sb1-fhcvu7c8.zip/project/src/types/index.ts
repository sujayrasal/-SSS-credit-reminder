export interface CustomerRecord {
  id?: string;
  customer_name: string;
  store_name: string;
  customer_contact?: string;
  items_purchased: string;
  purchase_date: string;
  payment_status: 'Pending' | 'Partial' | 'Paid';
  amount_pending: number;
  amount_paid: number;
  created_at?: string;
  updated_at?: string;
}

export interface FilterOptions {
  searchTerm: string;
  paymentStatus: 'All' | 'Pending' | 'Partial' | 'Paid';
  sortBy: 'date' | 'amount';
  sortOrder: 'asc' | 'desc';
}

export type Language = 'en' | 'mr';

export interface AppSettings {
  language: Language;
  storeName: string;
}