import React, { useState, useMemo } from 'react';
import { Plus, Database, Wifi, WifiOff } from 'lucide-react';
import { LanguageProvider } from './contexts/LanguageContext';
import { AuthProvider } from './contexts/AuthContext';
import { ProtectedRoute } from './components/ProtectedRoute';
import { Header } from './components/Header';
import { Navigation } from './components/Navigation';
import { AddRecordForm } from './components/AddRecordForm';
import { SearchAndFilter } from './components/SearchAndFilter';
import { RecordTable } from './components/RecordTable';
import { AccountSummary } from './components/AccountSummary';
import { Settings } from './components/Settings';
import { useCustomerRecords } from './hooks/useCustomerRecords';
import { useLanguage } from './contexts/LanguageContext';
import { FilterOptions } from './types';

const AppContent: React.FC = () => {
  const { t } = useLanguage();
  const { records, loading, error, addRecord, updateRecord, deleteRecord } = useCustomerRecords();
  const [activeTab, setActiveTab] = useState<'customers' | 'account' | 'settings'>('customers');
  const [showAddForm, setShowAddForm] = useState(false);
  const [filters, setFilters] = useState<FilterOptions>({
    searchTerm: '',
    paymentStatus: 'All',
    sortBy: 'date',
    sortOrder: 'desc',
  });

  const filteredAndSortedRecords = useMemo(() => {
    let filtered = records.filter(record => {
      const matchesSearch = 
        record.customer_name.toLowerCase().includes(filters.searchTerm.toLowerCase()) ||
        record.store_name.toLowerCase().includes(filters.searchTerm.toLowerCase()) ||
        (record.customer_contact && record.customer_contact.includes(filters.searchTerm));
      
      const matchesStatus = 
        filters.paymentStatus === 'All' || record.payment_status === filters.paymentStatus;

      return matchesSearch && matchesStatus;
    });

    filtered.sort((a, b) => {
      if (filters.sortBy === 'date') {
        const dateA = new Date(a.purchase_date).getTime();
        const dateB = new Date(b.purchase_date).getTime();
        return filters.sortOrder === 'desc' ? dateB - dateA : dateA - dateB;
      } else {
        return filters.sortOrder === 'desc' 
          ? b.amount_pending - a.amount_pending
          : a.amount_pending - b.amount_pending;
      }
    });

    return filtered;
  }, [records, filters]);

  const totals = useMemo(() => {
    return records.reduce(
      (acc, record) => ({
        customers: acc.customers + 1,
        pending: acc.pending + record.amount_pending,
        paid: acc.paid + record.amount_paid,
      }),
      { customers: 0, pending: 0, paid: 0 }
    );
  }, [records]);

  const isUsingSupabase = !error || !error.includes('local storage');

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading customer records...</p>
        </div>
      </div>
    );
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'customers':
        return (
          <>
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-2">{t('customerRecords')}</h2>
                <div className="flex items-center space-x-2">
                  <p className="text-gray-600">{t('manageCredit')}</p>
                  <div className="flex items-center space-x-1">
                    {isUsingSupabase ? (
                      <>
                        <Wifi className="h-4 w-4 text-green-600" />
                        <span className="text-xs text-green-600 font-medium">Cloud Sync</span>
                      </>
                    ) : (
                      <>
                        <WifiOff className="h-4 w-4 text-orange-600" />
                        <span className="text-xs text-orange-600 font-medium">Local Storage</span>
                      </>
                    )}
                  </div>
                </div>
              </div>
              <button
                onClick={() => setShowAddForm(true)}
                className="mt-4 sm:mt-0 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center space-x-2"
              >
                <Plus className="h-4 w-4" />
                <span>{t('addNewRecord')}</span>
              </button>
            </div>

            {error && error.includes('local storage') && (
              <div className="mb-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-center space-x-2">
                  <Database className="h-5 w-5 text-blue-600" />
                  <div>
                    <p className="text-blue-800 font-medium">Using Local Storage</p>
                    <p className="text-blue-700 text-sm">
                      Your data is stored locally. Connect to Supabase for cloud sync and access from multiple devices.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {isUsingSupabase && (
              <div className="mb-6 bg-green-50 border border-green-200 rounded-lg p-4">
                <div className="flex items-center space-x-2">
                  <Database className="h-5 w-5 text-green-600" />
                  <div>
                    <p className="text-green-800 font-medium">Connected to Supabase</p>
                    <p className="text-green-700 text-sm">
                      Your data is securely stored in the cloud and synced across all your devices.
                    </p>
                  </div>
                </div>
              </div>
            )}

            <SearchAndFilter filters={filters} onFiltersChange={setFilters} />
            <RecordTable 
              records={filteredAndSortedRecords}
              onUpdate={updateRecord}
              onDelete={deleteRecord}
            />
          </>
        );
      case 'account':
        return <AccountSummary records={records} />;
      case 'settings':
        return <Settings />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header 
        totalCustomers={totals.customers}
        totalPending={totals.pending}
        totalPaid={totals.paid}
      />
      <Navigation activeTab={activeTab} onTabChange={setActiveTab} />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderContent()}

        {showAddForm && (
          <AddRecordForm
            onAdd={addRecord}
            onClose={() => setShowAddForm(false)}
          />
        )}
      </main>
    </div>
  );
};

function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <ProtectedRoute>
          <AppContent />
        </ProtectedRoute>
      </AuthProvider>
    </LanguageProvider>
  );
}

export default App;