import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { CustomerRecord } from '../types';

export const useCustomerRecords = () => {
  const [records, setRecords] = useState<CustomerRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Check if Supabase is properly configured
  const isSupabaseConfigured = () => {
    const url = import.meta.env.VITE_SUPABASE_URL;
    const key = import.meta.env.VITE_SUPABASE_ANON_KEY;
    return url && key && url !== 'your-supabase-url' && key !== 'your-supabase-anon-key' && 
           !url.includes('demo.supabase.co');
  };

  const fetchRecords = async () => {
    try {
      setLoading(true);
      setError(null);
      
      // If Supabase is not configured, use localStorage
      if (!isSupabaseConfigured()) {
        const localData = localStorage.getItem('sss-customer-records');
        if (localData) {
          setRecords(JSON.parse(localData));
        }
        setError('Using local storage - Connect to Supabase for cloud sync');
        return;
      }

      const { data, error } = await supabase
        .from('customer_records')
        .select('*')
        .order('purchase_date', { ascending: false });

      if (error) throw error;
      
      // Migrate any existing localStorage data to Supabase
      const localData = localStorage.getItem('sss-customer-records');
      if (localData && (!data || data.length === 0)) {
        const localRecords = JSON.parse(localData);
        if (localRecords.length > 0) {
          console.log('Migrating local data to Supabase...');
          for (const record of localRecords) {
            const { id, created_at, updated_at, ...recordData } = record;
            await supabase.from('customer_records').insert([recordData]);
          }
          // Fetch again after migration
          const { data: migratedData } = await supabase
            .from('customer_records')
            .select('*')
            .order('purchase_date', { ascending: false });
          setRecords(migratedData || []);
          localStorage.removeItem('sss-customer-records'); // Clean up
          return;
        }
      }
      
      setRecords(data || []);
    } catch (err) {
      console.error('Database error:', err);
      setError(err instanceof Error ? err.message : 'Database connection failed');
      // Fallback to localStorage
      const localData = localStorage.getItem('sss-customer-records');
      if (localData) {
        setRecords(JSON.parse(localData));
      }
    } finally {
      setLoading(false);
    }
  };

  const addRecord = async (record: Omit<CustomerRecord, 'id'>) => {
    try {
      if (!isSupabaseConfigured()) {
        // Fallback to localStorage
        const newRecord = { ...record, id: Date.now().toString() };
        const updatedRecords = [newRecord, ...records];
        setRecords(updatedRecords);
        localStorage.setItem('sss-customer-records', JSON.stringify(updatedRecords));
        return { success: true, data: newRecord };
      }

      const { data, error } = await supabase
        .from('customer_records')
        .insert([record])
        .select()
        .single();

      if (error) throw error;
      setRecords(prev => [data, ...prev]);
      return { success: true, data };
    } catch (err) {
      console.error('Add record error:', err);
      // Fallback to localStorage
      const newRecord = { ...record, id: Date.now().toString() };
      const updatedRecords = [newRecord, ...records];
      setRecords(updatedRecords);
      localStorage.setItem('sss-customer-records', JSON.stringify(updatedRecords));
      return { success: true, data: newRecord };
    }
  };

  const updateRecord = async (id: string, updates: Partial<CustomerRecord>) => {
    try {
      if (!isSupabaseConfigured()) {
        // Fallback to localStorage
        const updatedRecords = records.map(record => 
          record.id === id ? { ...record, ...updates } : record
        );
        setRecords(updatedRecords);
        localStorage.setItem('sss-customer-records', JSON.stringify(updatedRecords));
        return { success: true };
      }

      const { data, error } = await supabase
        .from('customer_records')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      setRecords(prev => prev.map(record => record.id === id ? data : record));
      return { success: true, data };
    } catch (err) {
      console.error('Update record error:', err);
      // Fallback to localStorage
      const updatedRecords = records.map(record => 
        record.id === id ? { ...record, ...updates } : record
      );
      setRecords(updatedRecords);
      localStorage.setItem('sss-customer-records', JSON.stringify(updatedRecords));
      return { success: true };
    }
  };

  const deleteRecord = async (id: string) => {
    try {
      if (!isSupabaseConfigured()) {
        // Fallback to localStorage
        const updatedRecords = records.filter(record => record.id !== id);
        setRecords(updatedRecords);
        localStorage.setItem('sss-customer-records', JSON.stringify(updatedRecords));
        return { success: true };
      }

      const { error } = await supabase
        .from('customer_records')
        .delete()
        .eq('id', id);

      if (error) throw error;
      setRecords(prev => prev.filter(record => record.id !== id));
      return { success: true };
    } catch (err) {
      console.error('Delete record error:', err);
      // Fallback to localStorage
      const updatedRecords = records.filter(record => record.id !== id);
      setRecords(updatedRecords);
      localStorage.setItem('sss-customer-records', JSON.stringify(updatedRecords));
      return { success: true };
    }
  };

  useEffect(() => {
    fetchRecords();
  }, []);

  return {
    records,
    loading,
    error,
    addRecord,
    updateRecord,
    deleteRecord,
    refetch: fetchRecords,
  };
};