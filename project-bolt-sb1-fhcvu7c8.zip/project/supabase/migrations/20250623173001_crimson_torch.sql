/*
  # Create customer records table

  1. New Tables
    - `customer_records`
      - `id` (uuid, primary key)
      - `customer_name` (text, required)
      - `store_name` (text, required)
      - `items_purchased` (text, required)
      - `purchase_date` (date, required)
      - `payment_status` (text, enum: Pending/Partial/Paid, default: Pending)
      - `amount_pending` (numeric, default: 0)
      - `amount_paid` (numeric, default: 0)
      - `created_at` (timestamp, auto-generated)
      - `updated_at` (timestamp, auto-updated)

  2. Security
    - Enable RLS on `customer_records` table
    - Add policy for public access (since this is a single-user grocery store app)

  3. Indexes
    - Index on customer_name for faster searches
    - Index on purchase_date for sorting
    - Index on payment_status for filtering
*/

-- Create the customer_records table
CREATE TABLE IF NOT EXISTS customer_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name text NOT NULL,
  store_name text NOT NULL,
  items_purchased text NOT NULL,
  purchase_date date NOT NULL,
  payment_status text NOT NULL DEFAULT 'Pending' CHECK (payment_status IN ('Pending', 'Partial', 'Paid')),
  amount_pending numeric(10,2) NOT NULL DEFAULT 0,
  amount_paid numeric(10,2) NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE customer_records ENABLE ROW LEVEL SECURITY;

-- Create policy for public access (suitable for single-user grocery store app)
CREATE POLICY "Allow all operations for everyone"
  ON customer_records
  FOR ALL
  TO public
  USING (true)
  WITH CHECK (true);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_customer_records_customer_name ON customer_records(customer_name);
CREATE INDEX IF NOT EXISTS idx_customer_records_purchase_date ON customer_records(purchase_date DESC);
CREATE INDEX IF NOT EXISTS idx_customer_records_payment_status ON customer_records(payment_status);
CREATE INDEX IF NOT EXISTS idx_customer_records_created_at ON customer_records(created_at DESC);

-- Create function to automatically update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger to automatically update updated_at
CREATE TRIGGER update_customer_records_updated_at
  BEFORE UPDATE ON customer_records
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();