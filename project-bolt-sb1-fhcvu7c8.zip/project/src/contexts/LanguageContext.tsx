import React, { createContext, useContext, useState, useEffect } from 'react';
import { Language } from '../types';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const translations = {
  en: {
    // Navigation
    customers: 'Customers',
    account: 'Account',
    settings: 'Settings',
    
    // Header
    appTitle: 'SSS Credit Reminder',
    appSubtitle: 'Shri Swami Samarth Traders - Credit Management',
    totalCustomers: 'Customers',
    totalPending: 'Pending',
    totalCollected: 'Collected',
    
    // Customer Management
    addNewRecord: 'Add New Record',
    customerRecords: 'Customer Records',
    manageCredit: 'Manage credit records for your grocery store customers',
    
    // Form Fields
    customerName: 'Customer Name',
    storeName: 'Store Name',
    customerContact: 'Customer Contact',
    itemsPurchased: 'Items Purchased',
    purchaseDate: 'Purchase Date',
    paymentStatus: 'Payment Status',
    amountPending: 'Amount Pending (₹)',
    amountPaid: 'Amount Paid (₹)',
    
    // Status
    pending: 'Pending',
    partial: 'Partial',
    paid: 'Paid',
    
    // Actions
    add: 'Add',
    edit: 'Edit',
    delete: 'Delete',
    save: 'Save',
    cancel: 'Cancel',
    sendReminder: 'Send Reminder',
    
    // Messages
    noRecords: 'No records found. Add your first customer record to get started.',
    deleteConfirm: 'Are you sure you want to delete this record?',
    
    // Search & Filter
    searchPlaceholder: 'Search by customer name, store name, or contact...',
    allStatus: 'All Status',
    sortByDate: 'Date',
    sortByAmount: 'Amount',
    
    // Account Summary
    accountSummary: 'Account Summary',
    totalRevenue: 'Total Revenue',
    outstandingAmount: 'Outstanding Amount',
    collectedAmount: 'Collected Amount',
    
    // Settings
    appSettings: 'App Settings',
    language: 'Language',
    english: 'English',
    marathi: 'मराठी',
    aboutApp: 'About App',
    version: 'Version',
    
    // WhatsApp Message Template
    reminderMessage: 'Dear {customerName}, this is a reminder about your pending payment of ₹{amount} for items purchased from Shri Swami Samarth Traders on {date}. Please do your payment. Thank you!',
  },
  mr: {
    // Navigation
    customers: 'ग्राहक',
    account: 'खाते',
    settings: 'सेटिंग्ज',
    
    // Header
    appTitle: 'एसएसएस क्रेडिट रिमाइंडर',
    appSubtitle: 'श्री स्वामी समर्थ ट्रेडर्स - क्रेडिट व्यवस्थापन',
    totalCustomers: 'ग्राहक',
    totalPending: 'बाकी',
    totalCollected: 'गोळा केले',
    
    // Customer Management
    addNewRecord: 'नवीन रेकॉर्ड जोडा',
    customerRecords: 'ग्राहक रेकॉर्ड',
    manageCredit: 'आपल्या किराणा दुकानातील ग्राहकांसाठी क्रेडिट रेकॉर्ड व्यवस्थापित करा',
    
    // Form Fields
    customerName: 'ग्राहकाचे नाव',
    storeName: 'दुकानाचे नाव',
    customerContact: 'ग्राहक संपर्क',
    itemsPurchased: 'खरेदी केलेल्या वस्तू',
    purchaseDate: 'खरेदीची तारीख',
    paymentStatus: 'पेमेंट स्थिती',
    amountPending: 'बाकी रक्कम (₹)',
    amountPaid: 'भरलेली रक्कम (₹)',
    
    // Status
    pending: 'बाकी',
    partial: 'अर्धवट',
    paid: 'भरले',
    
    // Actions
    add: 'जोडा',
    edit: 'संपादित करा',
    delete: 'हटवा',
    save: 'जतन करा',
    cancel: 'रद्द करा',
    sendReminder: 'रिमाइंडर पाठवा',
    
    // Messages
    noRecords: 'कोणतेही रेकॉर्ड सापडले नाहीत. सुरुवात करण्यासाठी आपला पहिला ग्राहक रेकॉर्ड जोडा.',
    deleteConfirm: 'आपल्याला खात्री आहे की आपण हा रेकॉर्ड हटवू इच्छिता?',
    
    // Search & Filter
    searchPlaceholder: 'ग्राहकाचे नाव, दुकानाचे नाव किंवा संपर्कानुसार शोधा...',
    allStatus: 'सर्व स्थिती',
    sortByDate: 'तारीख',
    sortByAmount: 'रक्कम',
    
    // Account Summary
    accountSummary: 'खाते सारांश',
    totalRevenue: 'एकूण महसूल',
    outstandingAmount: 'थकित रक्कम',
    collectedAmount: 'गोळा केलेली रक्कम',
    
    // Settings
    appSettings: 'अॅप सेटिंग्ज',
    language: 'भाषा',
    english: 'English',
    marathi: 'मराठी',
    aboutApp: 'अॅप बद्दल',
    version: 'आवृत्ती',
    
    // WhatsApp Message Template - Updated to exact format requested
    reminderMessage: 'प्रिय {customerName}, श्री स्वामी समर्थ ट्रेडर्स कडून {date} रोजी खरेदी केलेल्या वस्तूंसाठी ₹{amount} मागील बाकी आहे. कृपया लवकरात लवकर भरणा करा. धन्यवाद!',
  },
};

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>(() => {
    const saved = localStorage.getItem('sss-language');
    return (saved as Language) || 'en';
  });

  useEffect(() => {
    localStorage.setItem('sss-language', language);
  }, [language]);

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations['en']] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};