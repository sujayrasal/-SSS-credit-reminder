import React from 'react';
import { TrendingUp, TrendingDown, DollarSign, Users } from 'lucide-react';
import { CustomerRecord } from '../types';
import { formatCurrency } from '../utils/currency';
import { useLanguage } from '../contexts/LanguageContext';

interface AccountSummaryProps {
  records: CustomerRecord[];
}

export const AccountSummary: React.FC<AccountSummaryProps> = ({ records }) => {
  const { t } = useLanguage();

  const summary = React.useMemo(() => {
    return records.reduce(
      (acc, record) => ({
        totalCustomers: acc.totalCustomers + 1,
        totalRevenue: acc.totalRevenue + record.amount_pending + record.amount_paid,
        outstandingAmount: acc.outstandingAmount + record.amount_pending,
        collectedAmount: acc.collectedAmount + record.amount_paid,
        pendingCustomers: acc.pendingCustomers + (record.amount_pending > 0 ? 1 : 0),
      }),
      {
        totalCustomers: 0,
        totalRevenue: 0,
        outstandingAmount: 0,
        collectedAmount: 0,
        pendingCustomers: 0,
      }
    );
  }, [records]);

  const collectionRate = summary.totalRevenue > 0 
    ? (summary.collectedAmount / summary.totalRevenue) * 100 
    : 0;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-6">{t('accountSummary')}</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <Users className="h-8 w-8 text-blue-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">{t('totalCustomers')}</p>
              <p className="text-2xl font-semibold text-gray-900">{summary.totalCustomers}</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <DollarSign className="h-8 w-8 text-green-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">{t('totalRevenue')}</p>
              <p className="text-2xl font-semibold text-gray-900">{formatCurrency(summary.totalRevenue)}</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <TrendingDown className="h-8 w-8 text-red-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">{t('outstandingAmount')}</p>
              <p className="text-2xl font-semibold text-gray-900">{formatCurrency(summary.outstandingAmount)}</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <TrendingUp className="h-8 w-8 text-green-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">{t('collectedAmount')}</p>
              <p className="text-2xl font-semibold text-gray-900">{formatCurrency(summary.collectedAmount)}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Collection Rate</h3>
          <div className="flex items-center">
            <div className="flex-1">
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-green-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${Math.min(collectionRate, 100)}%` }}
                ></div>
              </div>
            </div>
            <div className="ml-4">
              <span className="text-2xl font-semibold text-gray-900">{collectionRate.toFixed(1)}%</span>
            </div>
          </div>
          <p className="text-sm text-gray-500 mt-2">
            {formatCurrency(summary.collectedAmount)} collected out of {formatCurrency(summary.totalRevenue)}
          </p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Pending Payments</h3>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-gray-600">Customers with pending payments:</span>
              <span className="font-semibold text-red-600">{summary.pendingCustomers}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Average pending per customer:</span>
              <span className="font-semibold text-gray-900">
                {summary.pendingCustomers > 0 
                  ? formatCurrency(summary.outstandingAmount / summary.pendingCustomers)
                  : formatCurrency(0)
                }
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};