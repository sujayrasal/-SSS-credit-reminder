import React from 'react';
import { Users, PieChart, Settings, Globe } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface NavigationProps {
  activeTab: 'customers' | 'account' | 'settings';
  onTabChange: (tab: 'customers' | 'account' | 'settings') => void;
}

export const Navigation: React.FC<NavigationProps> = ({ activeTab, onTabChange }) => {
  const { t, language, setLanguage } = useLanguage();

  const tabs = [
    { id: 'customers' as const, label: t('customers'), icon: Users },
    { id: 'account' as const, label: t('account'), icon: PieChart },
    { id: 'settings' as const, label: t('settings'), icon: Settings },
  ];

  return (
    <nav className="bg-white border-b border-gray-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <div className="flex space-x-8">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              
              return (
                <button
                  key={tab.id}
                  onClick={() => onTabChange(tab.id)}
                  className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                    isActive
                      ? 'border-green-500 text-green-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Icon className="h-5 w-5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
          
          <div className="flex items-center space-x-2">
            <Globe className="h-4 w-4 text-gray-500" />
            <button
              onClick={() => setLanguage(language === 'en' ? 'mr' : 'en')}
              className="px-3 py-1 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200 transition-colors"
            >
              {language === 'en' ? 'मराठी' : 'English'}
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};