import React from 'react';
import { Search, Filter, SortAsc, SortDesc } from 'lucide-react';
import { FilterOptions } from '../types';
import { useLanguage } from '../contexts/LanguageContext';

interface SearchAndFilterProps {
  filters: FilterOptions;
  onFiltersChange: (filters: FilterOptions) => void;
}

export const SearchAndFilter: React.FC<SearchAndFilterProps> = ({ filters, onFiltersChange }) => {
  const { t } = useLanguage();

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onFiltersChange({ ...filters, searchTerm: e.target.value });
  };

  const handleStatusChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    onFiltersChange({ ...filters, paymentStatus: e.target.value as FilterOptions['paymentStatus'] });
  };

  const handleSortChange = (sortBy: FilterOptions['sortBy']) => {
    const newSortOrder = filters.sortBy === sortBy && filters.sortOrder === 'desc' ? 'asc' : 'desc';
    onFiltersChange({ ...filters, sortBy, sortOrder: newSortOrder });
  };

  return (
    <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 mb-6">
      <div className="flex flex-col lg:flex-row space-y-4 lg:space-y-0 lg:space-x-4">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder={t('searchPlaceholder')}
              value={filters.searchTerm}
              onChange={handleSearchChange}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            />
          </div>
        </div>

        <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-4">
          <div className="flex items-center space-x-2">
            <Filter className="h-4 w-4 text-gray-400" />
            <select
              value={filters.paymentStatus}
              onChange={handleStatusChange}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            >
              <option value="All">{t('allStatus')}</option>
              <option value="Pending">{t('pending')}</option>
              <option value="Partial">{t('partial')}</option>
              <option value="Paid">{t('paid')}</option>
            </select>
          </div>

          <div className="flex space-x-2">
            <button
              onClick={() => handleSortChange('date')}
              className={`flex items-center space-x-1 px-3 py-2 rounded-lg border transition-colors ${
                filters.sortBy === 'date'
                  ? 'bg-green-50 border-green-200 text-green-700'
                  : 'border-gray-300 hover:bg-gray-50'
              }`}
            >
              <span>{t('sortByDate')}</span>
              {filters.sortBy === 'date' && (
                filters.sortOrder === 'desc' ? <SortDesc className="h-4 w-4" /> : <SortAsc className="h-4 w-4" />
              )}
            </button>

            <button
              onClick={() => handleSortChange('amount')}
              className={`flex items-center space-x-1 px-3 py-2 rounded-lg border transition-colors ${
                filters.sortBy === 'amount'
                  ? 'bg-green-50 border-green-200 text-green-700'
                  : 'border-gray-300 hover:bg-gray-50'
              }`}
            >
              <span>{t('sortByAmount')}</span>
              {filters.sortBy === 'amount' && (
                filters.sortOrder === 'desc' ? <SortDesc className="h-4 w-4" /> : <SortAsc className="h-4 w-4" />
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};