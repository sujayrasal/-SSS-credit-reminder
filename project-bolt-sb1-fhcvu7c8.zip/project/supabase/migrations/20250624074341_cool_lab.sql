/*
  # Add customer contact number to customer records

  1. Changes
    - Add `customer_contact` column to `customer_records` table
    - Add index for faster contact-based searches

  2. Security
    - Maintain existing RLS policies
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'customer_records' AND column_name = 'customer_contact'
  ) THEN
    ALTER TABLE customer_records ADD COLUMN customer_contact text;
  END IF;
END $$;

-- Create index for contact searches
CREATE INDEX IF NOT EXISTS idx_customer_records_contact ON customer_records(customer_contact);