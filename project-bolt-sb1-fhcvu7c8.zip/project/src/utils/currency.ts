export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 2,
  }).format(amount);
};

export const calculateTotalAmount = (amountPending: number, amountPaid: number): number => {
  return amountPending + amountPaid;
};

export const determinePaymentStatus = (amountPending: number): 'Pending' | 'Partial' | 'Paid' => {
  if (amountPending === 0) return 'Paid';
  return 'Pending'; // This can be enhanced to detect 'Partial' based on business logic
};